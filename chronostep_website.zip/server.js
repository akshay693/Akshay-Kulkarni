
const express = require('express');
const path = require('path');
const bodyParser = require('body-parser');
const session = require('express-session');
const methodOverride = require('method-override');
const { db } = require('./utils/db');
const store = new session.MemoryStore(); // for demo/dev only

const app = express();
const PORT = process.env.PORT || 3000;

// View engine
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static
app.use(express.static(path.join(__dirname, 'public')));

// Middlewares
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.use(methodOverride('_method'));
app.use(session({
  secret: process.env.SESSION_SECRET || 'devsecret',
  resave: false,
  saveUninitialized: true,
  store
}));

// Attach cart to locals
app.use((req, res, next) => {
  if (!req.session.cart) req.session.cart = { items: [], totalQty: 0, totalAmount: 0 };
  res.locals.cart = req.session.cart;
  res.locals.path = req.path;
  next();
});

// Routes
const shopRoutes = require('./routes/shop');
const adminRoutes = require('./routes/admin');
const cartRoutes = require('./routes/cart');

app.use('/', shopRoutes);
app.use('/cart', cartRoutes);
app.use('/admin', adminRoutes);

// 404
app.use((req, res) => {
  res.status(404).render('404', { title: 'Not Found' });
});

app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
