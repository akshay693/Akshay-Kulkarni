
# SHOPMart (Shoes • Watches • Eyewear)

A minimal, dynamic e-commerce starter built with **Node.js (Express + EJS)** and **SQLite**.

## Features
- Category pages for **Shoes**, **Watches**, **Eyewear**
- Product pages, search
- Cart & checkout (stores orders in SQLite)
- Simple admin (add/edit/delete products & add categories) — demo user **admin/admin**
- Clean dark UI

## Quick Start
1) Install Node.js (v18+ recommended).
2) In the project folder, run:
```bash
npm install
npm run init   # creates DB and seeds demo data
npm start
```
3) Open **http://localhost:3000**

### Admin
- Visit **http://localhost:3000/admin**
- Login with **admin / admin** (change this in DB for production)
- Add categories and products, edit or delete existing ones

## Environment (optional)
- `PORT=3000`
- `SESSION_SECRET=your-secret`

## Notes
- Images are placeholders located in `/public/img`. Replace them with real images or external URLs.
- This is a demo/starter. For production, add proper authentication, CSRF protection, file uploads, payment gateway, etc.
