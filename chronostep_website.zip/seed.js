
const { db } = require('./utils/db');
const slugify = require('slugify');

const categories = ['Shoes', 'Watches', 'Eyewear'];

const sample = {
  'Shoes': [
    { name: 'Runner Pro 1', price: 3499, image: '/img/shoe1.jpg', description: 'Lightweight running shoes with breathable mesh.'},
    { name: 'Urban Sneak', price: 2899, image: '/img/shoe2.jpg', description: 'Daily-wear sneakers with comfy insole.'},
  ],
  'Watches': [
    { name: 'Chrono Steel', price: 5999, image: '/img/watch1.jpg', description: 'Stainless steel chronograph with date.'},
    { name: 'Minimalist Leather', price: 4499, image: '/img/watch2.jpg', description: 'Sleek dial with genuine leather strap.'},
  ],
  'Eyewear': [
    { name: 'Aviator Classic', price: 1999, image: '/img/eye1.jpg', description: 'Timeless aviator sunglasses with UV400.'},
    { name: 'BlueShield Pro', price: 1499, image: '/img/eye2.jpg', description: 'Blue-light blocking glasses for screens.'},
  ]
};

db.serialize(() => {
  // Insert categories
  categories.forEach(cat => {
    db.run('INSERT OR IGNORE INTO categories (name, slug) VALUES (?,?)', [cat, slugify(cat, { lower: true })]);
  });

  // Insert products
  categories.forEach(cat => {
    const catSlug = slugify(cat, { lower: true });
    db.get('SELECT id FROM categories WHERE slug = ?', [catSlug], (err, row) => {
      if (err || !row) return;
      const catId = row.id;
      sample[cat].forEach(p => {
        const slug = slugify(p.name, { lower: true }) + '-' + Math.floor(Math.random()*10000);
        db.run('INSERT OR IGNORE INTO products (name, slug, description, price, image, category_id) VALUES (?,?,?,?,?,?)',
          [p.name, slug, p.description, p.price, p.image, catId]);
      });
    });
  });

  // Default admin user (demo: admin/admin)
  db.run('INSERT OR IGNORE INTO users (username, password) VALUES (?,?)', ['admin', 'admin']);
});

console.log('Seeded categories, products, and demo admin user.');
