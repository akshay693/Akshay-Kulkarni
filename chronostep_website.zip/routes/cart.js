
const express = require('express');
const router = express.Router();
const { db } = require('../utils/db');

function recalc(cart){
  cart.totalQty = cart.items.reduce((a,b)=>a+b.qty,0);
  cart.totalAmount = cart.items.reduce((a,b)=>a+b.qty*b.price,0);
}

router.post('/add', (req, res) => {
  const slug = req.body.slug;
  db.get('SELECT id, name, price, image, slug FROM products WHERE slug=?', [slug], (err, p) => {
    if (!p) return res.redirect('/');
    if (!req.session.cart) req.session.cart = { items: [], totalQty:0, totalAmount:0 };
    const cart = req.session.cart;
    const idx = cart.items.findIndex(i => i.slug === slug);
    if (idx>-1) cart.items[idx].qty += 1;
    else cart.items.push({ product_id: p.id, name: p.name, price: p.price, image: p.image, slug: p.slug, qty:1 });
    recalc(cart);
    res.redirect('/cart');
  });
});

router.get('/', (req, res) => {
  res.render('cart', { title: 'Your Cart' });
});

router.post('/update', (req, res) => {
  const { slug, qty } = req.body;
  const cart = req.session.cart;
  const item = cart.items.find(i => i.slug === slug);
  if (item) {
    item.qty = Math.max(1, parseInt(qty||'1',10));
    recalc(cart);
  }
  res.redirect('/cart');
});

router.post('/remove', (req, res) => {
  const { slug } = req.body;
  const cart = req.session.cart;
  cart.items = cart.items.filter(i => i.slug !== slug);
  recalc(cart);
  res.redirect('/cart');
});

router.get('/checkout', (req, res) => {
  res.render('checkout', { title: 'Checkout' });
});

router.post('/checkout', (req, res) => {
  const { name, email, phone, address } = req.body;
  const cart = req.session.cart;
  if (!cart || cart.items.length === 0) return res.redirect('/cart');
  const total = cart.totalAmount;
  const { db } = require('../utils/db');
  db.run('INSERT INTO orders (name, email, phone, address, total_amount) VALUES (?,?,?,?,?)',
    [name, email, phone, address, total], function(err){
      if (err) return res.send('Error creating order');
      const orderId = this.lastID;
      const stmt = db.prepare('INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?,?,?,?)');
      cart.items.forEach(i => stmt.run(orderId, i.product_id, i.qty, i.price));
      stmt.finalize();
      req.session.cart = { items: [], totalQty:0, totalAmount:0 };
      res.render('order-success', { title: 'Order Placed', orderId });
    });
});

module.exports = router;
