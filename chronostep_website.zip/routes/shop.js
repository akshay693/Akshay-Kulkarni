
const express = require('express');
const router = express.Router();
const { db } = require('../utils/db');

router.get('/', (req, res) => {
  db.all('SELECT * FROM categories', [], (err, categories) => {
    db.all('SELECT p.*, c.name as category_name, c.slug as category_slug FROM products p LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.created_at DESC LIMIT 8', [], (e2, latest) => {
      res.render('home', { title: 'Home', categories: categories||[], latest: latest||[] });
    });
  });
});

router.get('/category/:slug', (req, res) => {
  const slug = req.params.slug;
  db.get('SELECT * FROM categories WHERE slug=?', [slug], (err, category) => {
    if (!category) return res.status(404).render('404', { title: 'Category not found' });
    db.all('SELECT * FROM products WHERE category_id=?', [category.id], (e2, products) => {
      res.render('category', { title: category.name, category, products: products||[] });
    });
  });
});

router.get('/product/:slug', (req, res) => {
  db.get('SELECT p.*, c.name as category_name, c.slug as category_slug FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.slug=?', [req.params.slug], (err, product) => {
    if (!product) return res.status(404).render('404', { title: 'Product not found' });
    res.render('product', { title: product.name, product });
  });
});

router.get('/search', (req, res) => {
  const q = req.query.q || '';
  const like = `%${q}%`;
  db.all('SELECT p.*, c.name as category_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.name LIKE ? OR p.description LIKE ?', [like, like], (err, products) => {
    res.render('search', { title: 'Search', q, products: products||[] });
  });
});

module.exports = router;
