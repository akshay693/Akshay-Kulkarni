
const express = require('express');
const router = express.Router();
const { db } = require('../utils/db');
const slugify = require('slugify');

function requireLogin(req, res, next){
  if (req.session && req.session.admin) return next();
  return res.redirect('/admin/login');
}

router.get('/login', (req, res) => {
  res.render('admin/login', { title: 'Admin Login', error: null });
});

router.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get('SELECT * FROM users WHERE username=? AND password=?', [username, password], (err, user) => {
    if (user) {
      req.session.admin = { id: user.id, username: user.username };
      res.redirect('/admin');
    } else {
      res.render('admin/login', { title: 'Admin Login', error: 'Invalid credentials' });
    }
  });
});

router.post('/logout', (req, res) => {
  req.session.admin = null;
  res.redirect('/admin/login');
});

router.get('/', requireLogin, (req, res) => {
  db.all('SELECT * FROM products ORDER BY created_at DESC', [], (err, products) => {
    res.render('admin/dashboard', { title: 'Dashboard', products: products||[] });
  });
});

// Create product form
router.get('/products/new', requireLogin, (req, res) => {
  db.all('SELECT * FROM categories', [], (err, categories) => {
    res.render('admin/product-form', { title: 'New Product', categories, product: null });
  });
});

router.post('/products', requireLogin, (req, res) => {
  const { name, description, price, image, category_id } = req.body;
  const slug = slugify(name, { lower: true }) + '-' + Math.floor(Math.random()*10000);
  db.run('INSERT INTO products (name, slug, description, price, image, category_id) VALUES (?,?,?,?,?,?)',
    [name, slug, description, parseInt(price,10), image, parseInt(category_id,10)], (err) => {
      res.redirect('/admin');
    });
});

router.get('/products/:id/edit', requireLogin, (req, res) => {
  db.get('SELECT * FROM products WHERE id=?', [req.params.id], (err, product) => {
    if (!product) return res.redirect('/admin');
    db.all('SELECT * FROM categories', [], (e2, categories) => {
      res.render('admin/product-form', { title: 'Edit Product', categories, product });
    });
  });
});

router.post('/products/:id', requireLogin, (req, res) => {
  const { name, description, price, image, category_id } = req.body;
  db.run('UPDATE products SET name=?, description=?, price=?, image=?, category_id=? WHERE id=?',
    [name, description, parseInt(price,10), image, parseInt(category_id,10), req.params.id], (err) => {
      res.redirect('/admin');
    });
});

router.post('/products/:id/delete', requireLogin, (req, res) => {
  db.run('DELETE FROM products WHERE id=?', [req.params.id], (err) => {
    res.redirect('/admin');
  });
});

// Category management (simple add)
router.post('/categories', requireLogin, (req, res) => {
  const { name } = req.body;
  const slug = slugify(name, { lower: true });
  db.run('INSERT OR IGNORE INTO categories (name, slug) VALUES (?,?)', [name, slug], () => res.redirect('/admin'));
});

module.exports = router;
